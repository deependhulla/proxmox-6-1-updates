package PVE::pvecfg;

use strict;
use warnings;

sub package {
    return 'pve-manager';
}

sub version {
    return '6.1-7';
}

sub release {
    return '6.1';
}

sub repoid {
    return '13e58d5e';
}

sub version_text {
    return '6.1-7/13e58d5e';
}

# this is returned by the API
sub version_info {
    return {
	'version' => '6.1-7',
	'release' => '6.1',
	'repoid' => '13e58d5e',
    }
}

1;
