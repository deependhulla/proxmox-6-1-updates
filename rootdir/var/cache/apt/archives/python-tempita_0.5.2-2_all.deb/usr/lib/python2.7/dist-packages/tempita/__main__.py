from tempita import fill_command

fill_command()
